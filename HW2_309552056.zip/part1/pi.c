#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdint.h>
#include <pthread.h>
#include <math.h>
long long number_of_tosses, total_number_in_circle;
unsigned int number_of_cores;
//typedef struct { uint64_t state;  uint64_t inc; } pcg32_random_t;
pthread_mutex_t mutex;
/*uint32_t pcg32_random_r(pcg32_random_t* rng)
{
    uint64_t oldstate = rng->state;
    // Advance internal state
    rng->state = oldstate * 6364136223846793005ULL + (rng->inc|1);
    // Calculate output function (XSH RR), uses old state for max ILP
    uint32_t xorshifted = ((oldstate >> 18u) ^ oldstate) >> 27u;
    uint32_t rot = oldstate >> 59u;
    return (xorshifted >> rot) | (xorshifted << ((-rot) & 31));
}*/

void* cal_pi(void *input){
	int tid = *(int*) input;
	double x,y;
	time_t t;
//	struct drand48_data randBuffer;
	unsigned int sum=0;
//	srand48_r(time(NULL), &randBuffer);
//	pcg32_random_t rngx,rngy;
	unsigned int seed = time(NULL);
//	rngx.state = seed;
//	rngx.inc = 1;
//	seed = time(NULL);
//	rngy.state = seed;
//	rngy.inc = 2;
	for (long long toss = 0; toss < number_of_tosses; toss ++) {
	   // resultx = pcg32_random_r(&rngx);
	   // rngx.state = resultx;
	  //  resulty = pcg32_random_r(&rngy);
	  //  rngy.state = resulty;
//	    x = ldexp(pcg32_random_r(&rngx), -32);
//	    y = ldexp(pcg32_random_r(&rngy), -32);
//	    y = (double) resulty/4294967296;
	    x = (double) rand_r(&seed)/(RAND_MAX+1.0);
	    y = (double) rand_r(&seed)/(RAND_MAX+1.0);
//	    distance_squared = x * x + y * y;
	    if ( x*x + y*y <= 1)
	       sum++;
	}
	pthread_mutex_lock(&mutex);
	total_number_in_circle+=sum;
	pthread_mutex_unlock(&mutex);
	pthread_exit(NULL);
}
int main(int argc, char* argv[]){
	if(argc<3) fprintf(stderr, "Too few arguments.\n");
	double pi_estimate;
	//gettimeofday(&start,NULL);
	number_of_cores = atoi(argv[1]);
	number_of_tosses = atoll(argv[2]);
	number_of_tosses /= number_of_cores;
	pthread_t *t;
	t = (pthread_t *)malloc(number_of_cores * sizeof(pthread_t));
	pthread_mutex_init(&mutex, NULL);
	for(int i=0; i<number_of_cores; i++)
		pthread_create(&t[i], NULL, cal_pi, (void*) &i);
	for(int i=0; i<number_of_cores; i++)
		pthread_join(t[i], NULL);
	pthread_mutex_destroy(&mutex);
	free(t);
	pi_estimate = (double)4 * total_number_in_circle /( number_of_tosses * number_of_cores);
	printf("%.10f\n",pi_estimate);
	//gettimeofday(&end, NULL);
	//unsigned long diff=1000000*(end.tv_sec-start.tv_sec)+end.tv_usec-start.tv_usec;
        //double ddiff=(double)diff/1000000;
        //printf("Time elasped: %f sec\n",ddiff);
}
